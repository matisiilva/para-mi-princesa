document.addEventListener('DOMContentLoaded', function() {
    const specialMessageBtn = document.getElementById('specialMessageBtn');
    const specialMessage = document.getElementById('specialMessage');
    const photoGallery = document.querySelector('.carousel-inner');
    const prevBtn = document.getElementById('prevBtn');
    const nextBtn = document.getElementById('nextBtn');
    const quotes = [
        '"El amor no mira con los ojos, sino con el alma." - William Shakespeare',
        '"Te quiero no por lo que eres, sino por lo que soy cuando estoy contigo." - Gabriel García Márquez',
        '"El amor es una amistad con música." - Joseph Campbell',
        '"En un beso, sabrás todo lo que he callado." - Pablo Neruda',
        '"Te amo más de lo que las palabras pueden decir." - [Tu Nombre]'
    ];
    const quoteDisplay = document.getElementById('quoteDisplay');
    let currentQuoteIndex = 0;
    let currentSlideIndex = 0;
    const slides = photoGallery.children;

    specialMessageBtn.addEventListener('click', function() {
        if (specialMessage.classList.contains('hidden')) {
            specialMessage.classList.remove('hidden');
            specialMessage.style.opacity = 1;
            specialMessageBtn.textContent = 'Ocultar Mensaje Especial';
        } else {
            specialMessage.classList.add('hidden');
            specialMessage.style.opacity = 0;
            specialMessageBtn.textContent = 'Ver Mensaje Especial';
        }
    });

    prevBtn.addEventListener('click',
